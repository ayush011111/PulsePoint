import express from "express";
import { createServer as createViteServer } from "vite";
import Groq from "groq-sdk";
import { createClient } from "@supabase/supabase-js";
import path from "path";
import fs from "fs";

// Initialize Groq
const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/process-report", async (req, res) => {
    try {
      const { report_id, raw_text, image_url, audio_url, latitude, longitude, people_affected } = req.body;
      
      let textToProcess = raw_text;
      
      // In a real app we'd process audio_url via Whisper here. 
      // For this demo we'll just check if there's audio.
      if (audio_url && !textToProcess) {
         textToProcess = "Audio report received."; 
      }

      // Prompt Groq to extract issue details
      const response = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "Extract from this community report: issue_type (one of: flood/fire/medical/food_shortage/shelter/infrastructure/other), severity (1-10), people_affected (integer), vulnerability_flag (boolean - true if elderly/children/disabled mentioned). Return JSON only."
          },
          {
            role: "user",
            content: `Report text: ${textToProcess || ""}`
          }
        ],
        model: "llama3-8b-8192", // Fast and cheap for structured extraction
        response_format: { type: "json_object" },
      });
      
      const structuredDataStr = response.choices[0]?.message?.content;
      if (!structuredDataStr) throw new Error("No structured data returned");
      
      const structuredData = JSON.parse(structuredDataStr);

      // Initialize Supabase Admin Client 
      // (Using service_role key to bypass RLS for Edge Function equivalent)
      const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
      const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      
      if (!supabaseUrl || !supabaseKey) {
        throw new Error("Supabase credentials not configured on server.");
      }
      
      const supabase = createClient(supabaseUrl, supabaseKey);

      // 4. Insert structured data into reports table (or update if report_id provided)
      let currentReportId = report_id;
      
      if (currentReportId) {
         await supabase.from('reports').update({
            extracted_issue_type: structuredData.issue_type,
            extracted_severity: structuredData.severity,
            people_affected: structuredData.people_affected || people_affected,
            vulnerability_flag: structuredData.vulnerability_flag,
            transcription_status: 'done'
         }).eq('id', currentReportId);
      } else {
         const { data: insertedReport, error: insertError } = await supabase.from('reports').insert({
            raw_text: textToProcess,
            image_url,
            audio_url,
            extracted_issue_type: structuredData.issue_type,
            extracted_severity: structuredData.severity,
            people_affected: structuredData.people_affected || people_affected,
            vulnerability_flag: structuredData.vulnerability_flag,
            location: `SRID=4326;POINT(${longitude} ${latitude})`,
            transcription_status: 'done',
         }).select('id').single();
         
         if (insertError) throw insertError;
         currentReportId = insertedReport.id;
      }

      // 5. Call cluster_report_into_issue() DB function
      const { data: issueId, error: clusterError } = await supabase.rpc('cluster_report_into_issue', {
        p_report_id: currentReportId,
        p_issue_type: structuredData.issue_type,
        p_location: `SRID=4326;POINT(${longitude} ${latitude})`,
        p_people_affected: structuredData.people_affected || people_affected,
        p_vulnerability_flag: structuredData.vulnerability_flag
      });

      if (clusterError) throw clusterError;

      // 6. Find tasks for this issue and run matching
      const { data: tasks, error: tasksError } = await supabase
        .from('tasks')
        .select('id, skills_required')
        .eq('issue_id', issueId)
        .eq('status', 'pending');
        
      if (!tasksError && tasks && tasks.length > 0) {
        for (const task of tasks) {
           const { data: matchedVolunteerId } = await supabase.rpc('match_volunteer_to_task', {
              p_task_id: task.id,
              p_issue_location: `SRID=4326;POINT(${longitude} ${latitude})`,
              p_skills_required: task.skills_required || []
           });
           
           if (!matchedVolunteerId) {
             console.log(`No volunteer matched for task ${task.id}`);
             // 7. If match returns NULL -> insert notification (omitted for brevity)
           }
        }
      }

      // 8. If issue urgency > 80 -> push via FCM (omitted for brevity)

      res.json({ success: true, issueId, currentReportId, data: structuredData });
    } catch (error: any) {
      console.error("Error processing report:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Determine the absolute path to the 'dist' directory
    const distPath = path.resolve(process.cwd(), "dist");
    
    // Explicitly serve static files from 'dist'
    app.use(express.static(distPath));
    
    // Explicitly handle SPA routing - serve index.html for all non-file routes
    app.get("*", (req, res, next) => {
      // Don't intercept API routes
      if (req.originalUrl.startsWith('/api')) {
        return next();
      }
      
      const indexPath = path.join(distPath, "index.html");
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send("Application not built.");
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
