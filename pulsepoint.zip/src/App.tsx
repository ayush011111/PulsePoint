import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import MapPage from './pages/MapPage';
import ReportPage from './pages/ReportPage';
import TasksPage from './pages/TasksPage';
import DashboardPage from './pages/DashboardPage';
import AuthPage from './pages/AuthPage';
import { Toaster } from 'sonner';
import { AuthProvider } from './lib/AuthContext';
import { AppLayout } from './components/layout';

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Navigate to="/map" replace />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/map" element={<MapPage />} />
            <Route path="/report" element={<ReportPage />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
          </Routes>
        </AppLayout>
        <Toaster />
      </AuthProvider>
    </Router>
  );
}
