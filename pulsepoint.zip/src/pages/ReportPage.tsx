import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { useAuth } from '@/lib/AuthContext';

export default function ReportPage() {
  const { user } = useAuth();
  const [description, setDescription] = useState('');
  const [peopleAffected, setPeopleAffected] = useState(1);
  const [hasVulnerable, setHasVulnerable] = useState(false);
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error("Error getting location", error);
          toast.error("Could not obtain location. Using default.");
          setLocation({ lat: 40.7128, lng: -74.0060 }); // Default
        }
      );
    } else {
      setLocation({ lat: 40.7128, lng: -74.0060 });
    }
  }, []);

  const handleSubmit = async () => {
    if (!description) {
      toast.error("Please provide a description");
      return;
    }
    if (!location) {
      toast.error("Location not available yet");
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/process-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          raw_text: description,
          latitude: location.lat,
          longitude: location.lng,
          people_affected: peopleAffected,
          vulnerability_flag: hasVulnerable,
          submitted_by: user?.id
        })
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to submit report");
      }

      toast.success("Report submitted successfully");
      setDescription('');
      setPeopleAffected(1);
      setHasVulnerable(false);
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Failed to submit report");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex-1 bg-slate-900 h-full overflow-y-auto p-6 flex justify-center">
      <div className="w-full max-w-2xl">
        <h2 className="text-xl font-bold font-sans text-white mb-6 uppercase tracking-tight">Submit Community Report</h2>
        
        <div className="bg-slate-950 border border-slate-800 p-6 flex flex-col gap-6 relative shadow-2xl">
           <div className="absolute top-0 right-0 p-2 text-[10px] font-mono text-slate-600 bg-slate-900 border-b border-l border-slate-800">SECURE CHANNEL</div>
           
           <div className="flex flex-col gap-2">
             <label className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Incident Description</label>
             <textarea 
               value={description}
               onChange={(e) => setDescription(e.target.value)}
               className="bg-slate-900 border border-slate-700 text-sm text-slate-200 p-3 min-h-[120px] focus:outline-none focus:border-slate-500 rounded-none transition-colors"
               placeholder="Describe the issue, location, and severity..."
             ></textarea>
           </div>
           
           <div className="grid grid-cols-2 gap-6">
             <div className="flex flex-col gap-2">
               <label className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">People Affected (Est.)</label>
               <input 
                 type="number"
                 min={1}
                 value={peopleAffected}
                 onChange={(e) => setPeopleAffected(parseInt(e.target.value) || 1)}
                 className="bg-slate-900 border border-slate-700 text-sm text-slate-200 p-3 focus:outline-none focus:border-slate-500 rounded-none transition-colors"
               />
             </div>
             
             <div className="flex flex-col gap-2 justify-end">
               <label className="flex items-center gap-3 cursor-pointer p-3 border border-slate-700 bg-slate-900 hover:bg-slate-800 transition-colors">
                 <input 
                   type="checkbox" 
                   checked={hasVulnerable}
                   onChange={(e) => setHasVulnerable(e.target.checked)}
                   className="accent-red-500 w-4 h-4" 
                 />
                 <span className="text-xs font-bold text-orange-400 uppercase tracking-wide">Vulnerable Groups Present</span>
               </label>
             </div>
           </div>

           <div className="flex gap-4 items-center pt-4 border-t border-slate-800">
             <button className="flex-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-xs font-bold uppercase tracking-widest py-4 transition-colors">
               + Add Media (Photo/Voice)
             </button>
             <button 
               onClick={handleSubmit}
               disabled={isSubmitting}
               className="flex-1 bg-white hover:bg-slate-200 text-slate-950 text-xs font-bold uppercase tracking-widest py-4 transition-colors border border-white disabled:opacity-50"
             >
               {isSubmitting ? "PROCESSING..." : "Submit Report to AI Pipeline"}
             </button>
           </div>
        </div>
      </div>
    </div>
  );
}
