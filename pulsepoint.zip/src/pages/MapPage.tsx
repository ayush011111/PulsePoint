import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icon in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function MapPage() {
  const center: [number, number] = [40.7128, -74.0060];

  return (
    <div className="flex-1 bg-slate-900 relative overflow-hidden h-full flex flex-col">
      <div className="absolute inset-0 z-0">
        <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }} zoomControl={false}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            className="map-tiles"
          />
        </MapContainer>
      </div>
      
      {/* Map UI Overlays (z-10 to stay on top of map) */}
      <div className="absolute top-6 left-6 flex flex-col gap-2 z-10 pointer-events-none">
        <div className="bg-slate-950/90 border border-slate-700 p-3 rounded shadow-xl w-64 pointer-events-auto">
          <div className="text-[10px] text-slate-500 font-mono mb-1">LAT: {center[0]} | LNG: {center[1]}</div>
          <div className="text-sm font-bold text-white">Full Map Context</div>
          <div className="text-xs text-slate-400 mt-1">Ready for real markers</div>
        </div>
      </div>
      
      <div className="absolute bottom-6 left-6 flex gap-2 z-10">
        <button className="bg-slate-950 border border-slate-700 px-4 py-2 text-xs font-bold hover:bg-slate-800 transition-colors">STREET VIEW</button>
        <button className="bg-slate-950 border border-slate-700 px-4 py-2 text-xs font-bold hover:bg-slate-800 transition-colors">HEATMAP</button>
        <button className="bg-slate-950 border border-slate-700 px-4 py-2 text-xs font-bold hover:bg-slate-800 text-red-400 transition-colors">FILTER CRITICAL</button>
      </div>
      
      <style>{`
        .map-tiles {
          filter: invert(100%) hue-rotate(180deg) brightness(95%) contrast(90%);
        }
      `}</style>
    </div>
  );
}
