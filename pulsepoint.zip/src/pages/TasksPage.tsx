import React from 'react';

export default function TasksPage() {
  return (
    <div className="flex-1 bg-slate-900 h-full overflow-hidden flex flex-col p-6">
      <div className="max-w-5xl w-full mx-auto flex flex-col h-full gap-4">
        <h2 className="text-xl font-bold font-sans text-white uppercase tracking-tight">Active Assignments</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-1 min-h-0">
          
          {/* Active Tasks Column */}
          <div className="flex flex-col gap-px bg-slate-800 md:col-span-2 overflow-hidden shadow-2xl border border-slate-800">
             <div className="bg-slate-950 p-4 shrink-0 flex justify-between items-center border-b border-slate-800">
               <span className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">My Pipeline</span>
               <span className="text-[10px] font-mono text-green-400">1 ACTIVE</span>
             </div>
             
             <div className="flex-1 overflow-y-auto bg-slate-800 space-y-px">
               {/* Task Item */}
               <div className="bg-slate-900 p-6 flex flex-col gap-4">
                 <div className="flex justify-between items-start">
                   <div>
                     <div className="text-[10px] text-blue-400 font-bold uppercase mb-1">FOOD_SHORTAGE</div>
                     <h3 className="text-sm font-bold text-white">Distribute food supplies at Downtown Hub</h3>
                   </div>
                   <div className="text-[10px] px-2 py-1 bg-green-500/10 text-green-400 font-mono border border-green-500/20">ACTIVE</div>
                 </div>
                 
                 <div className="text-xs text-slate-400">
                   Requires: Logistics
                 </div>
                 
                 <div className="flex gap-4 pt-4 border-t border-slate-800">
                   <button className="bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 text-xs font-bold transition-colors">UPLOAD PROOF</button>
                   <button className="bg-white hover:bg-slate-200 text-slate-950 px-4 py-2 text-xs font-bold transition-colors">MARK COMPLETE</button>
                 </div>
               </div>
               
               {/* Available task item (simulated format) */}
               <div className="bg-slate-950 p-6 flex flex-col gap-4 opacity-70 border-l-4 border-slate-600 hover:opacity-100 transition-opacity">
                 <div className="flex justify-between items-start">
                   <div>
                     <div className="text-[10px] text-slate-500 font-bold uppercase mb-1">SHELTER</div>
                     <h3 className="text-sm font-bold text-white">Set up emergency shelter at West Park</h3>
                   </div>
                   <div className="text-[10px] px-2 py-1 bg-slate-800 text-slate-400 font-mono border border-slate-700">PENDING VOLUNTEER</div>
                 </div>
                 <div className="text-xs text-slate-400">
                   Skill match: 80% (You have Logistics)
                 </div>
                 <div className="flex gap-4 pt-4 border-t border-slate-800">
                   <button className="bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white px-4 py-2 text-xs font-bold transition-colors">ACCEPT TASK</button>
                 </div>
               </div>
             </div>
          </div>
          
          {/* Stats Column */}
          <div className="bg-slate-950 border border-slate-800 shadow-2xl p-6 flex flex-col gap-6">
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-500 tracking-widest mb-2">My Impact</div>
              <div className="text-4xl font-light text-white tracking-tighter">14</div>
              <div className="text-[10px] text-slate-400 mt-1">Tasks Completed</div>
            </div>
            
            <div className="h-px bg-slate-800"></div>
            
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-500 tracking-widest mb-2">Availability</div>
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]"></div>
                <span className="text-xs font-bold text-white uppercase tracking-wide">Available</span>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}
