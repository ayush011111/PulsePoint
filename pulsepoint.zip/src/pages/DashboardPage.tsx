import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/AuthContext';
import { Card } from '@/components/ui/card';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icon in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function DashboardPage() {
  const { profile } = useAuth();
  
  if (profile?.role !== 'ngo' && profile?.role !== 'admin') {
    return <div className="p-8 text-red-500 font-mono text-sm block">UNAUTHORIZED ACCESS</div>;
  }

  const center: [number, number] = [40.7128, -74.0060];

  return (
    <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-px bg-slate-800 h-full">
      {/* Left Column: Map Interface */}
      <div className="md:col-span-8 bg-slate-900 relative overflow-hidden flex flex-col">
        <div className="absolute inset-0 z-0">
          <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }} zoomControl={false}>
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              className="map-tiles"
            />
          </MapContainer>
        </div>
        
        <div className="absolute top-6 left-6 flex flex-col gap-2 z-10 pointer-events-none">
          <div className="bg-slate-950/90 border border-slate-700 p-3 rounded shadow-xl w-64 pointer-events-auto">
            <div className="text-[10px] text-slate-500 font-mono mb-1">LAT: {center[0]} | LNG: {center[1]}</div>
            <div className="text-sm font-bold text-white">Dashboard Overview Map</div>
            <div className="text-xs text-slate-400 mt-1">Global System View</div>
          </div>
        </div>
        
        <div className="absolute bottom-6 left-6 flex gap-2 z-10">
          <button className="bg-slate-950 border border-slate-700 px-4 py-2 text-xs font-bold hover:bg-slate-800 transition-colors">STREET VIEW</button>
          <button className="bg-slate-950 border border-slate-700 px-4 py-2 text-xs font-bold hover:bg-slate-800 transition-colors">HEATMAP</button>
          <button className="bg-slate-950 border border-slate-700 px-4 py-2 text-xs font-bold hover:bg-slate-800 text-red-400 transition-colors">FILTER CRITICAL</button>
        </div>

        <style>{`
          .map-tiles {
            filter: invert(100%) hue-rotate(180deg) brightness(95%) contrast(90%);
          }
        `}</style>
      </div>

      {/* Right Column: Dashboard Data */}
      <div className="md:col-span-4 bg-slate-950 flex flex-col h-full overflow-hidden">
        
        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-px bg-slate-800 border-b border-slate-800 shrink-0">
          <div className="bg-slate-950 p-4">
            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-1">Active Issues</div>
            <div className="text-3xl font-light text-white tracking-tighter">--</div>
            <div className="text-[10px] text-red-400 font-medium">Realtime update pending</div>
          </div>
          <div className="bg-slate-950 p-4">
            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-1">Volunteers</div>
            <div className="text-3xl font-light text-white tracking-tighter">--</div>
            <div className="text-[10px] text-green-400 font-medium">Loading schema data</div>
          </div>
        </div>

        {/* High Density Issue List */}
        <div className="flex-1 overflow-hidden flex flex-col bg-slate-800 min-h-0">
          <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex justify-between items-center shrink-0">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Live Urgent Queue</span>
            <span className="text-[10px] font-mono text-slate-500">AWAITING DB...</span>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-px bg-slate-800">
             {/* Dynamic Issue items will go here later */}
             <div className="bg-slate-950 p-4 border-l-4 border-slate-700 opacity-60">
                <div className="text-[11px] text-slate-400">Loading issues...</div>
             </div>
          </div>
        </div>

        {/* Verification Queue Footer */}
        <div className="h-48 bg-slate-900 border-t border-slate-800 p-4 flex flex-col shrink-0">
          <div className="text-[10px] font-bold text-slate-400 uppercase mb-3 flex items-center justify-between">
            <span>Pending Task Verification</span>
            <span className="text-slate-600">0 AWAITING APPROVAL</span>
          </div>
          {/* Dynamic tasks will go here */}
          <div className="text-[10px] font-mono text-slate-600 text-center py-4">No tasks pending verification</div>
        </div>
      </div>
    </div>
  );
}
