import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function AuthPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState('');
  const [role, setRole] = useState<'volunteer' | 'ngo'>('volunteer');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate('/map');
      } else {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (data.user) {
          // Pre-populate user profile (will be handled by trigger in a real app, 
          // or we can insert explicitly if RLS allows, but usually we just update it).
          await supabase.from('users').update({ name, role }).eq('id', data.user.id);
        }
        toast.success("Account created. You can now log in.");
        setIsLogin(true);
      }
    } catch (err: any) {
      toast.error(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
      <div className="flex items-center gap-4 mb-12">
        <div className="w-10 h-10 bg-red-600 rounded-sm flex items-center justify-center font-bold text-white tracking-tighter text-xl shadow-[0_0_15px_rgba(220,38,38,0.5)]">PP</div>
        <h1 className="text-2xl font-bold tracking-tight text-white">PULSEPOINT <span className="text-red-500 font-mono text-sm ml-2">OS</span></h1>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-8 w-full max-w-md shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-600 to-orange-500"></div>
        
        <h2 className="text-sm font-bold text-slate-200 uppercase tracking-widest mb-6 border-b border-slate-800 pb-2">
          {isLogin ? 'Authentication Gateway' : 'New Operative Registration'}
        </h2>
        
        <form onSubmit={handleAuth} className="flex flex-col gap-4">
          {!isLogin && (
            <>
              <div className="flex flex-col gap-1">
                 <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Full Name</label>
                 <input 
                   type="text" value={name} onChange={e => setName(e.target.value)}
                   className="bg-slate-950 border border-slate-800 text-sm text-white p-3 focus:outline-none focus:border-slate-500 rounded-none w-full"
                   required
                 />
              </div>
              <div className="flex flex-col gap-1">
                 <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Role Assignment</label>
                 <select 
                   value={role} onChange={e => setRole(e.target.value as any)}
                   className="bg-slate-950 border border-slate-800 text-sm text-white p-3 focus:outline-none focus:border-slate-500 rounded-none w-full"
                 >
                   <option value="volunteer">Field Volunteer</option>
                   <option value="ngo">NGO Coordinator</option>
                 </select>
              </div>
            </>
          )}

          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Email Designation</label>
            <input 
              type="email" value={email} onChange={e => setEmail(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-sm text-white p-3 focus:outline-none focus:border-slate-500 rounded-none w-full"
              required
            />
          </div>
          
          <div className="flex flex-col gap-1 mb-2">
            <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Security Key</label>
            <input 
              type="password" value={password} onChange={e => setPassword(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-sm text-white p-3 focus:outline-none focus:border-slate-500 rounded-none w-full"
              required minLength={6}
            />
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-white hover:bg-slate-200 text-slate-950 text-xs font-bold uppercase tracking-widest py-4 transition-colors disabled:opacity-50"
          >
            {loading ? 'PROCESSING...' : (isLogin ? 'INITIALIZE LOGIN' : 'SUBMIT REGISTRATION')}
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-slate-800 text-center">
          <button 
            type="button" 
            onClick={() => setIsLogin(!isLogin)}
            className="text-[10px] font-mono text-slate-400 hover:text-white transition-colors uppercase"
          >
            {isLogin ? '» No credentials? Register here' : '« Return to Login Gateway'}
          </button>
        </div>
      </div>
      
      <div className="mt-8 text-[10px] font-mono text-slate-600 flex gap-4">
        <span>STATUS: SECURE</span>
        <span>///</span>
        <span>NODE: ALPHA-7</span>
      </div>
    </div>
  );
}
