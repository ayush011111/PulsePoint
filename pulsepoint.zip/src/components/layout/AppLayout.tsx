import React, { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { Link, useLocation, Navigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { toast } from 'sonner';

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, profile, signOut, loading } = useAuth();
  const location = useLocation();
  const [isTriggering, setIsTriggering] = useState(false);

  const handleDemoTrigger = async () => {
    setIsTriggering(true);
    toast.info("Injecting synthetic crisis report...", { id: "demo" });
    try {
      // Use map center + small offset
      const lat = 40.7128 + (Math.random() * 0.01 - 0.005);
      const lng = -74.0060 + (Math.random() * 0.01 - 0.005);
      
      const response = await fetch('/api/process-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          raw_text: "Flooding reported near community center, 30 families stranded, children present",
          latitude: lat,
          longitude: lng,
          people_affected: 30,
          vulnerability_flag: true
        })
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed pipeline");
      }
      
      toast.success("Pipeline executed successfully. Issue clustered and assigned.", { id: "demo" });
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Failed synthetic trigger", { id: "demo" });
    } finally {
      setIsTriggering(false);
    }
  };

  if (loading) {
     return <div className="h-screen bg-slate-950 flex items-center justify-center font-mono text-xs text-slate-500">INIT SYSTEM...</div>;
  }

  // Allow access to auth page
  if (location.pathname === '/auth') {
    if (user) {
       return <Navigate to="/map" replace />;
    }
    return <>{children}</>;
  }

  if (!user) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // Determine if pulse is active (e.g. mock crisis mode for now)
  const isCrisisMode = false;

  return (
    <div className="h-screen bg-slate-950 text-slate-200 font-sans overflow-hidden flex flex-col">
      {/* Top Navigation / Crisis Banner */}
      <div className={`h-14 ${isCrisisMode ? 'bg-red-600/10 border-red-500/30' : 'bg-slate-900 border-slate-800'} border-b flex items-center justify-between px-6 shrink-0`}>
        <div className="flex items-center gap-4">
          <div className={`w-8 h-8 ${isCrisisMode ? 'bg-red-600' : 'bg-slate-800'} rounded-sm flex items-center justify-center font-bold text-white tracking-tighter`}>PP</div>
          <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            PULSEPOINT 
            {isCrisisMode && <span className="text-red-500 text-xs font-mono ml-2">• CRISIS MODE ACTIVE</span>}
          </h1>
          <nav className="ml-8 flex gap-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            <Link to="/map" className={`hover:text-white ${location.pathname === '/map' ? 'text-white border-b-2 border-white' : ''} pb-1 px-1`}>Map</Link>
            <Link to="/report" className={`hover:text-white ${location.pathname === '/report' ? 'text-white border-b-2 border-white' : ''} pb-1 px-1`}>Report</Link>
            <Link to="/tasks" className={`hover:text-white ${location.pathname === '/tasks' ? 'text-white border-b-2 border-white' : ''} pb-1 px-1`}>Tasks</Link>
            {profile?.role && ['ngo', 'admin'].includes(profile.role) && (
              <Link to="/dashboard" className={`hover:text-white ${location.pathname === '/dashboard' ? 'text-white border-b-2 border-white' : ''} pb-1 px-1`}>Dashboard</Link>
            )}
          </nav>
        </div>
        <div className="flex items-center gap-6 text-[10px] font-mono">
          <div className="flex items-center gap-2 text-green-400">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div> DB: OK
          </div>
          <div className="flex items-center gap-2 text-blue-400">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></div> SYNC: OK
          </div>
          <div className="bg-slate-800 px-3 py-1 rounded flex items-center gap-2 text-white">
            {profile?.role === 'admin' ? '@' : ''}{profile?.name || user.email?.split('@')[0]}
            <button onClick={signOut} className="text-slate-400 hover:text-white ml-2"><LogOut className="w-3 h-3" /></button>
          </div>
        </div>
      </div>

      {/* Main Content Grid container from HTML (modified to hold page content) */}
      <div className="flex-1 overflow-hidden bg-slate-800 flex flex-col relative w-full h-full">
        {children}
      </div>

      {/* Bottom Action Rail */}
      <div className="h-12 bg-slate-950 border-t border-slate-800 flex items-center px-6 gap-6 justify-between shrink-0">
        <div className="flex items-center gap-6">
          {profile?.role === 'admin' && (
            <button 
              onClick={handleDemoTrigger}
              disabled={isTriggering}
              className="bg-red-600 text-white text-[10px] font-black uppercase px-4 h-8 tracking-widest hover:bg-red-500 active:bg-red-700 transition-colors disabled:opacity-50"
            >
              {isTriggering ? 'TRIGGERING...' : 'Demo Trigger: Crisis'}
            </button>
          )}
          <div className="h-4 w-px bg-slate-800 hidden md:block"></div>
          <div className="hidden md:flex gap-8">
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest">Latent latency</span>
              <span className="text-[10px] font-mono text-green-400">{(Math.random() * 200 + 40).toFixed(0)}ms</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest">AI Extraction</span>
              <span className="text-[10px] font-mono text-blue-400">READY</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest">Active Matchers</span>
              <span className="text-[10px] font-mono text-white">Edge Fn</span>
            </div>
          </div>
        </div>
        <div className="text-[10px] font-mono text-slate-600 tracking-wider">PULSEPOINT OS v1.0.4-BETA</div>
      </div>
    </div>
  );
}
